package com.airbnb.lottie;

public interface OnCompositionLoadedListener {
  void onCompositionLoaded(LottieComposition composition);
}
